<?php 

/**
* 
*/
class Result extends CI_Controller
{
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('ProductsModel');
		$this->load->library('pagination');	
	}

	public function index(){
		//Start Pagination
		$config=array();
		//fungsi array()
		$config['base_url']=base_url() . "Result";
		//menambahkan base / load base url . untuk di implementasikan pada product
		$config['per_page']=10;
		//setiap halaman per data
		$config['uri_segment']=2;
		//bagian-bagian dari url
		$config['total_rows']=$this->ProductsModel->/*isi function*/getTotalPrize();
		//membuat pagination disertai class
		$config['full_tag_open']="<ul>";
		$config['full_tag_close']="</ul>";

		$config['first_tag_open']="<li class='paging-item'>";
		$config['first-link']="&lt;&lt;";
		$config['first_tag_close']="</li>";

		$config['last_tag_open']="<li class='paging-item'>";
		$config['last_link']="&gt;&gt;";
		$config['last_tag_close']="</li>";

		$config['prev_tag_open']="<li class='paging-item'>";
		$config['prev_link']="&lt";
		$config['prev_tag_close']="</li'>";

		$config['next_tag_open']="<li class='paging-item'>";
		$config['next_link']="&gt";
		$config['next_tag_close']="</li'>";

		$config['cur_tag_open']="<li class='paging-item paging-item-active'><a >";
		$config['cur_tag_close']="</a></li>";

		$config['num_tag_open']="<li class='paging-item'>";
		$config['num_tag_close']="</li>";

		$this->pagination->initialize($config);
		//End Pagination

		$data['content_page']="result_content";

		$data['product_data']=$this->ProductsModel->getResult_prize_1();
		$data['product_data_before']=$this->ProductsModel->getResult_prize_1_yesterday(7);

		$data['product_data_1st']=$this->ProductsModel->getResult_prize_1(1);
		$data['product_data_1st_before']=$this->ProductsModel->getResult_prize_1_before(1);

		$data['product_data_spec_1']=$this->ProductsModel->getResult_spec_1(1);
		$data['product_data_spec_1_before']=$this->ProductsModel->getResult_spec_1_before(1);

		/*$data['product_data_hari']=$this->ProductsModel->getResult_prize_1_hari(7);*/
		$start_data=($this->uri->segment(2)) ? $this->uri->segment(2) : 0;
		//jika pada urutan ke dua tidak memiliki data maka menjalankan sesuai dengan urutan yaitu nol
		$koneksi = new mysqli('localhost','root','','sepakbo1_acac');
		$sql = "SELECT 1st_prize FROM waktu_tbl";
		
		$qsql = $koneksi->query($sql);
		$rsql = $qsql->fetch_assoc();

		date_default_timezone_set('Asia/Jakarta');
		$localtime = date('G:i:s');
		$schtime = $rsql['1st_prize'];
		//echo $localtime;echo ">";echo $schtime
		if($localtime>=$schtime){
			$data['product_data']=$this->ProductsModel->getResult_prize_1($start_data,$config['per_page']);
		}
		else{
			$data['product_data']=$this->ProductsModel->getResult_prize_1_before($start_data,$config['per_page']);
		}
		
		
		$this->load->view('index',$data);
	}

	



	
}
