<?php 
		include 'config.php';
		$sql = 'SELECT * FROM sidebar where sidebar_id LIMIT 0,1 ';
		$qsql = $koneksi->query($sql);
		$rsql = $qsql->fetch_assoc();
?>
			<div class="column pull-right sidebar no-gutter span-3">
				<?php echo $rsql['sidebar_custom']; ?>
				<aside id="" class="widget_text content push-bottom-large widget widget_custom_html" style="background:#b7c8de;"> 
					<a href="<?php echo base_url(); ?>Register" class="btn btn-primary btn-lg btn-block" style="text-decoration:none;">Register</a>
					<a href="<?php echo base_url(); ?>Login" class="btn btn-secondary btn-lg btn-block" style="text-decoration:none;">Login</a>
				</aside>
				<aside id="custom_html-3" class="widget_text content well push-bottom-large widget widget_custom_html">
					<h5 class="section-nav-title">Contact Us / اتصل بنا</h5>
					<div class="textwidget custom-html-widget">
						<?php echo $rsql['sidebar_contact']; ?>
					</div>
				</aside>
			</div>
		</div>
	</div>
</section>
