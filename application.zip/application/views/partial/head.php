<!DOCTYPE html>
<html lang="en-US" prefix="og: http://ogp.me/ns#">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
	<title>Home | تجمع دبي اليوم - احصل على رقم الحظ الخاص بك</title>

<!-- This site is optimized with the Yoast SEO plugin v9.6 - https://yoast.com/wordpress/plugins/seo/ -->
<link rel="canonical" href="index.html" />
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Home | تجمع دبي اليوم - احصل على رقم الحظ الخاص بك" />
<meta property="og:description" content="is the Finest Lottery in Dubai which operated since 2010 by the Millennium Millionaire which offers a one-in-5,000 chance to win US$1 million. Available throughout the world, Dubai Lottery has already created over 150.000 winners. Latest Lottery Result , Jackpot: د.إ 100,000 Draw No: How To Purchase / كيفية الشراء &hellip;" />
<meta property="og:url" content="index.html" />
<meta property="og:site_name" content="Dubai Pools Today" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:description" content="is the Finest Lottery in Dubai which operated since 2010 by the Millennium Millionaire which offers a one-in-5,000 chance to win US$1 million. Available throughout the world, Dubai Lottery has already created over 150.000 winners. Latest Lottery Result , Jackpot: د.إ 100,000 Draw No: How To Purchase / كيفية الشراء [&hellip;]" />
<meta name="twitter:title" content="Home | تجمع دبي اليوم - احصل على رقم الحظ الخاص بك" />
<meta name="twitter:image" content="wp-content/uploads/txt-dptcom.png" />
<script type='application/ld+json'>{"@context":"https://schema.org","@type":"WebSite","@id":"https://dubaipoolstoday.com/#website","url":"https://dubaipoolstoday.com/","name":"Dubai Pools Today","potentialAction":{"@type":"SearchAction","target":"https://dubaipoolstoday.com/?s={search_term_string}","query-input":"required name=search_term_string"}}</script>
<!-- / Yoast SEO plugin. -->
<link itemprop rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lalezar&subset=arabic,latin-ext,vietnamese" />



<link rel='dns-prefetch' href='http://fonts.googleapis.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link rel="alternate" type="application/rss+xml" title="Dubai Pools Today &raquo; Feed" href="feed/index.html" />
<link rel="alternate" type="application/rss+xml" title="Dubai Pools Today &raquo; Comments Feed" href="comments/feed/index.html" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/dubaipoolstoday.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.9"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>

			<style>
			#wp-admin-bar-layers-edit-layout .ab-icon:before{
				font-family: "layers-interface" !important;
				content: "\e62f" !important;
				font-size: 16px !important;
			}
			table td {
    text-align: center !important;
}
table th {
    text-align: center !important;
}
			</style>

			<link href="<?php echo base_url(); ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


	<link href="<?php echo base_url(); ?>css/heroic-features.css" rel="stylesheet">
		<link rel='stylesheet' id='layers-google-fonts-css'  href='http://fonts.googleapis.com/css?family=Fira+Sans%3Aregular%2Citalic%2C700%2C300%2C300italic%2C500%2C500italic%2C700italic%7CLato%3Aregular%2Citalic%2C700%2C100%2C100italic%2C300%2C300italic%2C700italic%2C900%2C900italic&amp;ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='layers-framework-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/css/framework6471.css?ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='layers-components-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/css/components6471.css?ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='layers-responsive-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/css/responsive6471.css?ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='layers-icon-fonts-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/css/layers-icons6471.css?ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='tablepress-default-css'  href='<?php echo base_url(); ?>wp-content/tablepress-combined.min544b.css?ver=9' type='text/css' media='all' />
<link rel='stylesheet' id='layers-pro-pro-css'  href='<?php echo base_url(); ?>wp-content/plugins/layers-pro-extension/assets/css/layers-pro7406.css?ver=2.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='layers-pro-animations-css'  href='<?php echo base_url(); ?>wp-content/plugins/layers-pro-extension/assets/css/animations7406.css?ver=2.0.1' type='text/css' media='all' />
<link rel='stylesheet' id='layers-font-awesome-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/core/assets/plugins/font-awesome/font-awesome.min6471.css?ver=2.0.10' type='text/css' media='all' />
<link rel='stylesheet' id='layers-style-css'  href='<?php echo base_url(); ?>wp-content/themes/layerswp/style6471.css?ver=2.0.10' type='text/css' media='all' />
<script type='text/javascript' src='<?php echo base_url(); ?>wp-includes/js/jquery/jqueryb8ff.js?ver=1.12.4'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>wp-includes/js/jquery/jquery-migrate.min330a.js?ver=1.4.1'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/js/plugins6471.js?ver=2.0.10'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var layers_script_settings = {"header_sticky_breakpoint":"270"};
/* ]]> */
</script>
<script type='text/javascript' src='<?php echo base_url(); ?>wp-content/themes/layerswp/assets/js/layers.framework6471.js?ver=2.0.10'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>wp-content/plugins/layers-pro-extension/assets/js/layers-pro7406.js?ver=2.0.1'></script>
<script type='text/javascript' src='<?php echo base_url(); ?>wp-content/plugins/layers-pro-extension/assets/js/jquery.plugins.min7406.js?ver=2.0.1'></script>
<link rel='https://api.w.org/' href='<?php echo base_url(); ?>wp-json/index.html' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo base_url(); ?>xmlrpc0db0.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo base_url(); ?>wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.9" />
<link rel='shortlink' href='index.html' />
		<!-- Custom Logo: hide header text -->
		<style id="custom-logo-css" type="text/css">
			.sitetitle, .tagline {
				position: absolute;
				clip: rect(1px, 1px, 1px, 1px);
			}
		</style>
	<link rel="alternate" type="application/json+oembed" href="<?php echo base_url(); ?>wp-json/oembed/1.0/embed62ef.json?url=https%3A%2F%2Fdubaipoolstoday.com%2F" />
<link rel="alternate" type="text/xml+oembed" href="<?php echo base_url(); ?>wp-json/oembed/1.0/embed39fa?url=https%3A%2F%2Fdubaipoolstoday.com%2F&amp;format=xml" />
<style type="text/css" id="layers-inline-styles-header">

 body { font-family: "Fira Sans", Helvetica, sans-serif;} 

 h1,h2,h3,h4,h5,h6, .heading { font-family: "Lato", Helvetica, sans-serif;} 

 .header-site nav.nav-horizontal .menu li { font-family: "Lato", Helvetica, sans-serif;} 

 button, .button, input[type=submit] { font-family: "Fira Sans", Helvetica, sans-serif;} 

 .header-site.invert .nav-horizontal > ul > li > a, .header-site .nav-horizontal > ul > li > a, .header-search a { border-radius: 4px;} 

 input[type="button"], input[type="submit"], button, .button, .form-submit input[type="submit"] { background: #023e73;color: #ffffff;border-width: 0px;border-radius: 4px;} 

 input[type="button"]:before, input[type="submit"]:before, button:before, .button:before, .form-submit input[type="submit"]:before input[type="button"]:after, input[type="submit"]:after, button:after, .button:after, .form-submit input[type="submit"]:after { color: #ffffff;} 

 input[type="button"]:hover, input[type="submit"]:hover, button:hover, .button:hover, .form-submit input[type="submit"]:hover { background: #256196;} 

 .invert input[type="button"], .invert input[type="submit"], .invert button, .invert .button, .invert .form-submit input[type="submit"] { border-width: 0px;border-radius: 0px;} 

 .header-site .nav-horizontal > ul > li { margin-left: 0px;margin-right: 0px;} 

@media only screen and ( min-width: 769px ) {.footer-site > .container > .row:first-child {padding-top : 30px ;padding-bottom : 30px ;}}

 .header-site, .header-site.header-sticky { background-color: #F3F3F3;} 

.footer-site {background-color: #ffffff;}

.sidebar .well {background-color: #FFFFFF;}</style>			<meta property="og:title" content="Home Page" />
							<meta property="og:description" content="is the Finest Lottery in Dubai which operated since 2010 by the Millennium Millionaire which offers a one-in-5,000 chance to win US$1 million. Available throughout the world, Dubai Lottery has already created over 150.000 winners. Latest Lottery Result , Jackpot: د.إ 100,000 Draw No: How To Purchase / كيفية الشراء [&hellip;]" />
						<meta property="og:type" content="website" />
			<meta property="og:url" content="https://dubaipoolstoday.com/" />
					<link rel="icon" href="<?php echo base_url(); ?>wp-content/uploads/2018/10/cropped-favico-dpt-32x32.jpg" sizes="32x32" />
<link rel="icon" href="<?php echo base_url(); ?>wp-content/uploads/2018/10/cropped-favico-dpt-192x192.jpg" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="<?php echo base_url(); ?>wp-content/uploads/2018/10/cropped-favico-dpt-180x180.jpg" />
<meta name="msapplication-TileImage" content="<?php echo base_url(); ?>/wp-content/uploads/2018/10/cropped-favico-dpt-270x270.jpg" />
		<style type="text/css" id="wp-custom-css">
			.container {
  max-width: 980px;
	padding: 0 15px !important;
}

#wrapper-site, .wrapper-site {
  background-color: #f4f4f4;
  background-image: url(<?php echo base_url(); ?>wp-content/uploads/bg-dpt-3.jpg);
  background-repeat: repeat-y;
  background-size: 100%;
  background-attachment: scroll;
}

.header-site {
  background-color: transparent;
}

.content-vertical-massive {
  padding-top: 15px;
  padding-bottom: 0;
}

.txt-center {
	text-align: center;
}

article.column {
	margin-bottom: 0px;
}

#banner-widget-area {
	margin-top: 3px;
	margin-bottom: 5px;
}

/* Custom Header Widget :: START */
#header-widget-area {
	position: absolute;
	top: 0px;
	right: 15px;
	z-index: -99;
}
/* Custom Header Widget :: END */

/* Menu Primary Hor :: START */
.responsive-nav .l-menu {
	color: #fff;
}

.nav {
	height: 90px;
	margin-bottom: 10px !important;
}

.nav-horizontal ul {
  width: 100% !important;
}

.header-site .nav-horizontal &gt; ul &gt; li {
	margin: auto;
}

#menu-primary-menu-1 li {
	font-size: 14px;
	width: 25%;
}

#menu-primary-menu-1 li.menu-item-23 {
	background-color: #023e73;
	background-image: url('<?php echo base_url(); ?>wp-content/uploads/icon-d1-48-g.png');
	background-repeat: no-repeat;
	background-position: top;
	height: 90px;
	padding-top: 45px;
}

#menu-primary-menu-1 li.menu-item-23 a {
	color: #fff;
}

#menu-primary-menu-1 li.menu-item-24 {
	background-color: #02736f;
	background-image: url('<?php echo base_url(); ?>wp-content/uploads/icon-d2-48-f.png');
	background-repeat: no-repeat;
	background-position: top;
	height: 90px;
	padding-top: 45px;
}

#menu-primary-menu-1 li.menu-item-24 a {
	color: #fff;
}

#menu-primary-menu-1 li.menu-item-25 {
	background-color: #d9ad29;
	background-image: url('<?php echo base_url(); ?>wp-content/uploads/icon-d3-48-f.png');
	background-repeat: no-repeat;
	background-position: top;
	height: 90px;
	padding-top: 45px;
}

#menu-primary-menu-1 li.menu-item-25 a {
	color: #fff;
}

#menu-primary-menu-1 li.menu-item-26 {
	background-color: #f2d888;
	background-image: url('<?php echo base_url(); ?>wp-content/uploads/icon-d4-48-f.png');
	background-repeat: no-repeat;
	background-position: top;
	height: 90px;
	padding-top: 45px;
}

#menu-primary-menu-1 li.menu-item-26 a {
	color: #001727;
}
/* Menu Primary Hor :: END */

.grid {
	margin-top: 8px;
}

header.section-title {
	display: none;
}

/* Block Blue :: START */
.div-blue {
	background-color: rgba(0, 23, 39, 0.8);
	color: #fff;
	margin-bottom: 15px;
}

h5.title-blue {
	background-color: #023e73;
	color: #fff;
	padding: 8px 15px 0px;
	margin-bottom: 0px;
}
/* Block Blue :: END */

/* Div Result :: START */
.div-result {
	background-color: #fff;
	margin-bottom: 15px;
	width: 100%;
}

h5.title-result {
	background-color: #001727;
	color: #fff;
	padding: 8px 15px 0px;
	margin-bottom: 0px;
}

h5.title-page-result {
	background-color: #001727;
	color: #fff;
	padding: 8px 15px;
	margin-bottom: 0px;
}

.result-daily {
	background: url(<?php echo base_url(); ?>wp-content/uploads/daily-draw-bg.png) no-repeat center;
  height: 175px;
	margin-bottom: 15px;
}

.result-daily .col-1 {
	width: 61.5%;
  float: left;
}

.result-daily .col-2 {
	width: 38.5%;
  float: right;
}

.result-daily .col-2 .jackpot-title {
	float: none;
  text-align: center;
  margin: 20px 0 0;
  width: auto;
  color: #9a4b00;
  font-size: 18px;
}

.result-daily .col-2 .jackpot-amount {
	float: none;
  text-align: center;
  margin: 0;
  width: auto;
  font-size: 30px;
	font-weight: 700;
	line-height: 36px;
}

.result-daily .col-2 .draw-no-title {
	float: none;
  text-align: center;
  margin: 10px 0 0;
  width: auto;
  color: #9a4b00;
  font-size: 14px;
  font-weight: 700;
}

.result-daily .col-2 .draw-no {
	float: none;
  text-align: center;
  margin: 0 0 30px;
  width: auto;
  font-size: 24px;
  font-weight: 700;
  color: #333;
}

.result-daily .title {
	margin: 20px 0 0 30px;
	color: #1d1c1c;
  font-size: 25px;
	font-weight: bold;
}

.result-daily .date {
	float: left;
  font-size: 14px;
  color: #1d1c1c;
  font-weight: 700;
  margin: 0 0 10px 30px;
}

.result-daily .date span {
	font-size: 20px !important;
}

ul.balls {
	float: left;
  overflow: hidden;
  margin: 2px 0 20px 25px;
  width: 650px;
}

.result-daily .ball {
	background: url(<?php echo base_url(); ?>wp-content/uploads/ball-free-lottery.png) no-repeat center 0;
  color: #333;
	background-position: center -91px;
}

.ball {
	float: left;
  position: relative;
  width: 58px;
  height: 58px;
  text-align: center;
  font-size:32px;
	font-weight:bold;
	line-height: 55px;
  padding: 0;
  vertical-align: top;
  margin: 0 0 0 5px !important;

}
.table thead th{
	     border-bottom: none; 
}
/*Ball*/
.result{
	margin-bottom:19px;
}

.h2_result{
	font-family: 'Lalezar', cursive;
    font-size: 20px;
    letter-spacing: 2px;
    margin-bottom: 10px;
    border-radius: 50px;
   /* background: linear-gradient(to bottom, #f7f7f791 0%, #9e7fbd 100%);*/

}

.ball_result{
	display:inline-block;line-height:50px;width:50px;background: radial-gradient(circle at 50% 50%, white 1px, #fbf0bf 3%,  60%, #735b26 100%);border-radius: 50%;color:#000;font-weight: bold;
}

.jumbotron {
	background:#d3e6c5;
	border-radius: 20px;
}

.information{
	margin-bottom:20px;
   	padding: 5px;	
    background: #faca39;
    color: #fff;
    border-top-right-radius: 20px;
    border-top-left-radius: 20px;
}
.information h2{
	color: #fff;
	letter-spacing: 2px;
	font-weight: bold;
	text-transform: uppercase;
}
.prize {
    padding: 5px;
    border: 2px solid #c7c7c7;
    border-radius:20px;
    margin-bottom:20px;
}
table{
	border-top-right-radius:20px;
	border-top-left-radius:20px;
}

table td{
	/*border-bottom:2px  solid #c7c7c7;*/
}

table th{
	/*border-bottom:2px  solid #c7c7c7 !important;*/
}

.border_prize{
	background: #000;
    padding: 1px;
    width: 50%;
    margin: auto;
    margin-bottom: 10px;
}

.wrapper-site{
	background:url(https://i2.wp.com/www.wallpapersbyte.com/wp-content/uploads/2015/07/Dubai-Al-Arab-UAE-United-Arab-Emirates-Hotel-Night-View-WallpapersByte-com-1366x768.jpg?w=1240&ssl=1);
	height: 100%;
	background-position: center;
	background-repeat: no-repeat;
	background-attachment: fixed;
	background-size:cover;
	 
}
/*End Ball*/
/*table result*/
.table td, .table th {
    padding: .75rem;
    vertical-align: top;
    border-top: 1px solid #c7c7c7;
}

.table_result{
	border-top-right-radius:0px;
	border-top-left-radius:0px;
	width: 100%;
}

.table_result th{
	color:#fff;
}

.no-padding{
	padding-right: 0px !important;
    padding-left: 0px !important;
}

.ball_result_page{
	display:inline-block;line-height:25px;width:25px;background: radial-gradient(circle at 50% 50%, white 1px, #fbf0bf 3%,  60%, #735b26 100%);border-radius: 50%;color:#000;font-weight: bold;
}


/*End table result*/
li.ball {
	list-style: none !important;
}
/* Div Result :: END */

/* How To :: START */
.div-darkblue {
	background-color: rgba(4, 46, 90, 0.7);
	color: #fff;
	margin-bottom: 15px;
}

h5.title-darkblue {
	background-color: #001727;
	color: #fff;
	padding: 8px 15px;
	margin-bottom: 0px;
}

ul.htp {
	display: inline-block;
	margin: 0px;
}

li.htp-img {
	list-style: none !important;
	width: 50%;
	margin: 0 !important;
	float: left;
	max-height: 143px;
}
/* How To :: END */

/* Notice :: START */
.div-notice {
	background-color: rgba(4, 46, 90, 0.7);
	color: #fff;
	margin-bottom: 15px;
	font-size: 12px;
	padding-bottom: 10px;
}

h5.title-notice {
	background-color: #001727;
	color: #fff;
	padding: 8px 15px;
	margin-bottom: 0px;
}

ul.ul-notice {
	padding-left: 5px;
}

ul.ul-notice li {
	list-style-image: url('<?php echo base_url(); ?>wp-content/uploads/ic-star-yellow.png');
	margin: 10px 0px !important;
	border-bottom: none !important;
	padding-right: 15px;
}

span.yellow-arabic {
	color: #ffcb3f;
}

span.blue-arabic {
	color: #023e73;
}

/* Notice :: END */

/* SideBar Green :: START */
aside#custom_html-2 {
	background-color: rgba(255, 255, 255, 0.7);
	color: #02736f;
	font-size: 12px;
	padding: 0px;
	font-weight: bold;
}

aside#custom_html-3 {
	background-color: rgba(255, 255, 255, 0.7);
	color: #02736f;
	font-size: 12px;
	padding: 0px;
	font-weight: bold;
}

aside#custom_html-3 h5 {
	background-image: url(<?php echo base_url(); ?>wp-content/uploads/phone-contact.png);
	background-repeat: no-repeat;
	background-position: 10px 10px;
	background-size: 36px;
	font-size: 16px;
	text-align: center;
	padding-left: 50px;
	padding-right: 50px;
}

div.phn-nbr {
	color: #ce260b;
	font-size: 20px;
	font-weight: normal;
	text-align: center;
	padding: 10px;
}

div.phn-title {
	color: #001727;
	font-weight: bold;
	font-size: 14px;
	padding: 0 10px 10px;
}

aside h5.section-nav-title {
	background-color: #02736f;
	color: #fff;
	padding: 8px 15px;
	margin-bottom: 0px;
}

div.brown-box {
	background-color: #d9ad29;
	color: #fff;
	padding: 28px 15px;
	margin: 5px;
	font-weight: bold;
	border-bottom: 3px solid #023e73;
}

div.yellow-box {
	background-color: #f2d888;
	color: #001727;
	padding: 12px 15px;
	margin: 3px 5px 5px;
	font-weight: bold;
	border-bottom: 3px solid #d9ad29;
}

.aside-excerpt {
	padding: 0px 20px 5px;
}

.aside-excerpt-phn {
	font-weight: normal;
	padding: 0px 20px 5px 10px;
}

.aside-excerpt ul {
	padding-left: 5px;
}

.aside-excerpt ul li {
	list-style-image: url('<?php echo base_url(); ?>wp-content/uploads/ic-star-yellow.png');
	margin: 10px 0px !important;
	border-bottom: none !important;
}

.aside-excerpt-phn ul li {
	border-bottom: none !important;
}

/* SideBar Green :: END */

.sidebar .well {
	background-color: transparent;
}

.widget_media_image {
	padding: 0px;	
}

.excerpt-block {
	padding: 8px 15px;
	font-size: 12px;
}

/* Footer :: START */
.footer-site {
	padding-top: 10px;
	padding-bottom: 5px;
}

.div-logo-footer {
	text-align: center;	
}

.div-logo-footer img {
	max-height: 96px;
	width: auto;
}

.div-bank-footer {
	text-align: center;
}

.footer-text {
	text-align: center;
	font-size: 12px;
	color: #979797;
}

.footer-text p {
	margin-top: 10px;
}
/* Footer :: END */

/* Ninja Table :: START */
.footable-filtering {
	display: none;
}

.semantic_ui .ui.table:not(.inverted) thead th {
	background: #023e73;
	color: #fff;
	text-align: center;
}

.semantic_ui .ui.table td {
	text-align: center !important;
}

.ninja_column_2, .ninja_column_3, .ninja_column_4, .ninja_column_5 {
	background: url(<?php echo base_url(); ?>wp-content/uploads/ball-free-lottery.png) no-repeat center 0;
  color: #333;
  background-position: center -40px;
  background-size: 36px;
  width: 36px;
  font-size: 24px;
  font-weight: 700;
}
/* Ninja Table :: END */

@media only screen and (min-width: 769px) {
	.nav-clear nav {
		margin: 0;
	}	
}

@media only screen and (max-width: 768px) {
	#header-widget-area {
		display: none;
	}
}

@media only screen and (max-width: 450px) {
	.result-daily .title {
		font-size: 18px;
	}
	
	.result-daily .col-2 {
		display: none;
	}
}		</style>
	</head>