<?php 
		include 'config.php';
		$sql = 'SELECT * FROM sidebar LIMIT 0,1';
		$qsql = $koneksi->query($sql);
		$rsql = $qsql->fetch_assoc();
?>
			<div class="column pull-right sidebar no-gutter span-3">
				<?php echo $rsql['sidebar_custom']; ?>
				<aside id="custom_html-3" class="widget_text content well push-bottom-large widget widget_custom_html">
					<h5 class="section-nav-title">Contact Us / اتصل بنا</h5>
					<div class="textwidget custom-html-widget">
						<?php echo $rsql['sidebar_contact']; ?>
					</div>
				</aside>
			</div>
		</div>
	</div>
</section>
