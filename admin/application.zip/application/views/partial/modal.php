<form class="form-theme form-md">
	<div class="col-md-12">
		<div class="row">
			<div class="col-md-12">
				<a class="btn btn-theme btn-lg center-block" data-toggle="modal" data-target="#modalForm"> Add Post </a>
			</div>
		</div>
	</div>
</form>

<div class="modal centered fade" id="modalForm" tabindex="-1" role="dialog" aria-labelledby="LoginPanel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content modal-background">
			<div class="modal-body pad-top-50 pad-bot-50 pad-left-50 pad-right-50">
				<div class="container-fluid">
					<div class="row">
						<div class="col-md-12">
							<h3 id="LoginPanel" class="no-margin-top mar-bot-30 text-uppercase text-center letter-spacing-1">Add Post</h3>
							<p class=" mar-bot-10 text-center letter-spacing-1"><small>Input to your account using your Email Address & Password</small></p>
							<form id="loginForm" class="form-theme mar-top-30" method="post" action="http://nucleus.amazyne.com/v2/dark/target.php" data-bv-message="This value is not valid" data-bv-feedbackicons-valid="glyphicon glyphicon-ok" data-bv-feedbackicons-invalid="glyphicon glyphicon-remove" data-bv-feedbackicons-validating="glyphicon glyphicon-refresh">
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="username" placeholder="Hari"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="form-group has-feedback">
											<input type="text" class="form-control modal-field" name="password" placeholder="Tanggal"/>
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2" style="margin-bottom:10px;">
										<div class="text-center">
											<input style="font-family:'Roboto Condensed', sans-serif;" type="reset" class="btn btn-theme btn-full-width">
										</div>
									</div>
								</div>
								<div class="row">
									<div class="col-sm-8 col-sm-offset-2">
										<div class="text-center">
											<input style="font-family:'Roboto Condensed', sans-serif;" type="submit" class="btn btn-theme btn-full-width">
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

