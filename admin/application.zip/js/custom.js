/********************************

Zenith's JavaScript Document for Custom Scripts
Created By: Amazyne Themes

*********************************/


	
	