<div id="post-10" class="container content-main clearfix post-10 page type-page status-publish hentry">
	<div class="grid">
		<article class="column span-9">
			<header class="section-title large post-header">
				<h1 class="heading">Home Page</h1>
					</header>
					<div class="story post-story">
						<div class="div-result">
							<h5 class="title-page-result">Lotto Results / نتائج اليانصيب</h5>
							<div class="table-result">
								<div id="footable_parent_490" class="footable_parent ninja_table_wrapper loading_ninja_table wp_table_data_press_parent semantic_ui ">
									<!-- Content here -->
									<div class="no-padding">
										<table class="table_result table-theme">
											<thead class="bg-yellow" style="background:#023e73 !important">
												<tr>
													<th>
														Prize
													</th>
													<th>
														Day
													</th>
													<th>
														Date
													</th>
													<th>
														Result
													</th>
												</tr>
											</thead>
											<tbody>
												<?php

													
													$koneksi = new mysqli('localhost','sepakbo1_dubai4dpools','Aa788888Wt@','sepakbo1_dubai4dpools');
													$sql = "SELECT 1st_prize FROM waktu_tbl";
													
													$qsql = $koneksi->query($sql);
													$rsql = $qsql->fetch_assoc();

													date_default_timezone_set('Asia/Jakarta');
													$localtime = date('G:i:s');
													$schtime = $rsql['1st_prize'];
													//echo $localtime;echo ">=";echo $schtime;
													
													if($localtime>=$schtime){
														foreach ($product_data as $data_1st) {
												?>
												<tr>
													<td>
														1
													</td>
													<td>
														<span style="text-transform:capitalize;"><?php echo $data_1st['hari']; ?></span>
													</td>
													<td>
														<?php 
															$date=date_create($data_1st['tanggal']);
															echo date_format($date,"d-m-Y");?> 	
													</td>
													<td>
														<div class="result_page" style="text-align:center;">
															<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,0,-3);?></span>
															<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,1,-2);?></span>
															<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,2,-1);?></span>
															<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,3,1);?></span>
														</div>
													</td>
												</tr>
												<?php } 
												}
												else
												{
														foreach ($product_data_before as $data_1st_before) {
													?>
													
												<tr>
													<td>
														1
													</td>
													<td>
														<span style="text-transform:capitalize;"><?php echo $data_1st_before['hari']; ?></span>
													</td>
													<td>
														<?php 
															$date=date_create($data_1st_before['tanggal']);
															echo date_format($date,"d-m-Y");?> 	
													</td>
													<td>
														<div class="result_page" style="text-align:center;">
														<span class="ball_result_page"><?php $data1=$data_1st_before['hasil_1'];echo $namafile= substr($data1,0,-3);?></span>
														<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,1,-2);?></span>
														<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,2,-1);?></span>
														<span class="ball_result_page"><?php $data1=$data_1st['hasil_1'];echo $namafile= substr($data1,3,1);?></span>
													</div>
													</td>
												</tr>
												<?php }
												}
											?>				
											</tbody>
										</table>
									</div>
									<!-- End Content -->
								</div>
							</div>
							<div class="pagination" style="margin-left:0px;">
				            <?php echo $this->pagination->create_links(); ?>
				        </div>
						</div>
						