<?php 
		include 'config.php';
		$sql = 'SELECT * FROM content LIMIT 0,1';
		$qsql = $koneksi->query($sql);
		$rsql = $qsql->fetch_assoc();

		echo $rsql['custom_site'];
?>