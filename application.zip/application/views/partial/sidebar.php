<div class="column pull-right sidebar no-gutter span-3">
							<aside id="media_image-4" class="content well push-bottom-large widget widget_media_image">
								<img width="295" height="161" src="wp-content/uploads/lottery-banner-1.jpg" class="image wp-image-149  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" />
							</aside>
							<aside id="media_image-3" class="content well push-bottom-large widget widget_media_image">
								<img width="295" height="182" src="wp-content/uploads/img-worav-banner-opt.gif" class="image wp-image-145  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" />
							</aside>
							<aside id="media_image-3" class="content well push-bottom-large widget widget_media_image">
								<img width="295" height="182" src="http://placehold.it/295x161" class="image wp-image-145  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" />
							</aside>
							<aside id="custom_html-3" class="widget_text content well push-bottom-large widget widget_custom_html">
								<h5 class="section-nav-title">Contact Us / اتصل بنا</h5>
								<div class="textwidget custom-html-widget">
									<div class="brown-box txt-center">
										Dubai Pools Today<br>Department Contact
									</div>
									<div class="phn-nbr">
										+971 4 888 3888
									</div>
									<div class="phn-title">
										Call Guidance
									</div>
									<div class="aside-excerpt-phn">
										<ul>
											<li>① Inquiries on the address and business hours of the lottery department</li>
											<li>② Opinions and requests on lottery tickets</li>
										</ul>
									</div>
									<div class="yellow-box txt-center">
										Call number guidance by telephone
									</div>
									<div class="aside-excerpt">
										<ul>
											<li>Telephone service
											</li>
										</ul>
									</div>
								</div>
							</aside>
						</div>
					</div>
				</div>
			</div id="back-to-top">
			<a href="#top">Back to top</a>
		</div> <!-- back-to-top -->
	</section>
