<?php 

	if(isset($content_page))
	{
		$this->load->view($content_page);	
	}
	
?>
