<?php $this->load->view('partial/head'); ?>
<?php $this->load->view('partial/header'); ?>
<?php $this->load->view('partial/chatslide'); ?>
<?php $this->load->view('partial/content'); ?>
<?php $this->load->view('partial/footer'); ?>



           