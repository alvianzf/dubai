<body class="home page-template page-template-template-right-sidebar page-template-template-right-sidebar-php page page-id-10 wp-custom-logo body-header-logo-top layers-post-page layers-pro-active">
	<div class="wrapper invert off-canvas-right" id="off-canvas-right">
    <a class="close-canvas" data-toggle="#off-canvas-right" data-toggle-class="open">
        <i class="l-close"></i>
        Close    </a>

    <div class="content nav-mobile clearfix">
        <nav class="nav nav-vertical"><ul id="menu-primary-menu" class="menu"><li id="menu-item-23" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-23"><a href="index.html">LOTTERY HOME</a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-24"><a href="index.html">HOW TO PURCHASE</a></li>
<li id="menu-item-25" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25"><a href="results/index.html">WINNING NUMBER<br>(NUMBERS)</a></li>
<li id="menu-item-26" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-26"><a href="index.html">LOTTERY POLICY</a></li>
</ul></nav>    </div>
    </div>		
    <div class="wrapper-site">

		
		
		
		<section class="header-site nav-clear layers-logo-large">
			            <div class="container header-block">
				<div class="logo">
	
	<a href="index.html" class="custom-logo-link" rel="home" itemprop="url"><img width="736" height="251" src="wp-content/uploads/2018/10/logo-dubaipoolstoday-h.jpg" class="custom-logo" alt="Dubai Pools Today" itemprop="logo" srcset="https://dubaipoolstoday.com/wp-content/uploads/2018/10/logo-dubaipoolstoday-h.jpg 736w, https://dubaipoolstoday.com/wp-content/uploads/2018/10/logo-dubaipoolstoday-h-300x102.jpg 300w" sizes="(max-width: 736px) 100vw, 736px" /></a>		<div class="site-description">
						<h3 class="sitename sitetitle"><a href="index.html">Dubai Pools Today</a></h3>
			<p class="tagline">Lucky Number is Yours Today</p>
					</div>
					<div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
			<div class="chw-widget"><img width="647" height="80" src="wp-content/uploads/dpt-header-banner-1.gif" class="image wp-image-224  attachment-full size-full" alt="" style="max-width: 100%; height: auto;" /></div>			</div>

	</div>

<nav class="nav nav-horizontal">
    
    <ul id="menu-primary-menu-1" class="menu">
    	<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-10 current_page_item menu-item-23">
    		<a href="Home">LOTTERY HOME</a>
    	</li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-24">
			<a href="Home">HOW TO PURCHASE</a>
		</li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25">
			<a href="Result">WINNING NUMBER<br>(NUMBERS)</a>
		</li>
		<li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-26">
			<a href="Home">LOTTERY POLICY</a>
		</li>
</ul>
    
    
<a class="responsive-nav"  data-toggle="#off-canvas-right" data-toggle-class="open">
	<span class="l-menu"></span>
</a>
</nav>			</div>
					</section>