<?php $this->load->view('partial/head'); ?>
<?php $this->load->view('partial/navigasi'); ?>
<?php $this->load->view('partial/content'); ?>
<?php $this->load->view('partial/content_bottom'); ?>
<?php $this->load->view('partial/sidebar'); ?>
<?php $this->load->view('partial/footer'); ?>