<?php
$koneksi = new mysqli("localhost","sepakbo1_dubai4dpools","Aa788888Wt@","sepakbo1_dubai4dpools");
?>