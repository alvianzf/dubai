<section id="footer" class="footer-site">
		<div class="container content clearfix">
		
								<div class="grid">
													<div class="column span-12 last">
						<aside id="custom_html-4" class="widget_text widget widget_custom_html"><div class="textwidget custom-html-widget"><div class="div-logo-footer">
	<img class="img-logo-footer" src="wp-content/uploads/2018/10/logo-dubaipoolstoday-h.jpg" alt="dubaipoolstoday.com" />
</div>
<div class="div-bank-footer">
	<img class="img-banks" src="wp-content/uploads/banks-eligible.jpg" alt="banks eligible" />
</div>
<div class="footer-text">
	<p>Dubai Pools Lottery Limited, of Burj Khalifa, Sheikh Mohamed Bin Rashid Boulevard, Downtown Dubai, Dubai, United Arab Emirates, is licensed by the Government of UAE and regulated by the UAE Lotto Commissioner under the UAE Gambling Act 2010 (Licences: <strong>RGL 085 &amp; 066</strong>), and is licensed and regulated by the Lottery Commission of UAE for customers in UAE (Licence: <strong>000-038991-R-319408-005</strong>). UAE Lotto Limited has a Remote Bookmaker’s Licence issued by the UAE National Excise Licence Office (Reference Number 1011284) for lotto buying activities in East Asia.</p>
<p>This website is operated by Dubai Pools. Dubai Pools has several Official Agents throughout Asia acting as a bookmaker. When buying tickets, Agent acts in the name and on behalf of the Player.</p>
<p>Persons under 18 years of age are not permitted to buy lottery.</p>
	<p>This is a real money lottery site. Please use it responsibly and only buy what you can afford. For symptom of addiction help and support, please contact Dubai Aware at <span class="blue-arabic">+971 4 888 3888</span> or visit <span class="blue-arabic">https://dubaipoolstoday.com</span></p>
	<p>Dubai Pools Today - The biggest Easy Asia and international lotteries at <span class="blue-arabic"><strong>dubaipoolstoday.com</strong></span></p>
</div></div></aside>					</div>
							</div>
					
				<div class="grid copyright">
						<div class="column span-6 clearfix t-right">
							</div>
		</div>
			</div>
	
	</section><!-- END / FOOTER -->


		<div class="search-interface-overlay">
			<form role="search" method="get" class="search-interface-holder" action="https://dubaipoolstoday.com/">
				<label class="search-text">
					Search:				</label>
				<input
					type="text"
					id="layers-modal-search-field"
					class="search-field"
					placeholder="Type Something"
					value=""
					name="s"
					title="Search for:"
					autocomplete="off"
					autocapitalize="off"
				>
			</form>
			<a href="#" class="search-close">
				<i class="l-close"></i>
			</a>
		</div>
		
	</div><!-- END / MAIN SITE #wrapper -->
		<link rel='stylesheet' id='metaslider-nivo-slider-css'  href='wp-content/plugins/ml-slider/assets/sliders/nivoslider/nivo-slider5900.css?ver=3.11.1' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider-public-css'  href='wp-content/plugins/ml-slider/assets/metaslider/public5900.css?ver=3.11.1' type='text/css' media='all' property='stylesheet' />
<link rel='stylesheet' id='metaslider-nivo-slider-default-css'  href='wp-content/plugins/ml-slider/assets/sliders/nivoslider/themes/default/default5900.css?ver=3.11.1' type='text/css' media='all' property='stylesheet' />
<script type='text/javascript' src='wp-includes/js/wp-embed.mind87f.js?ver=4.9.9'></script>
<script type='text/javascript' src='wp-content/plugins/ml-slider/assets/sliders/nivoslider/jquery.nivo.slider.pack5900.js?ver=3.11.1'></script>
<script type='text/javascript'>
var metaslider_426 = function($) {
            $('#metaslider_426').nivoSlider({ 
                boxCols:7,
                boxRows:5,
                pauseTime:3000,
                effect:"random",
                controlNav:false,
                directionNav:true,
                pauseOnHover:true,
                animSpeed:600,
                prevText:"Previous",
                nextText:"Next",
                slices:15,
                manualAdvance:false
            });
            $(document).trigger('metaslider/initialized', '#metaslider_426');
        };
        var timer_metaslider_426 = function() {
            var slider = !window.jQuery ? window.setTimeout(timer_metaslider_426, 100) : !jQuery.isReady ? window.setTimeout(timer_metaslider_426, 1) : metaslider_426(window.jQuery);
        };
        timer_metaslider_426();
</script>
</body>

</html>