<?php

$koneksi = new mysqli("localhost","root","","sepakbo1_acac");


?>